# Android QR Code/NFC Loyalty Card
QR Code/NFC Loyalty Card for Android

Only 2 things needed for a Digital Loyalty Card...  An Android Phone and a QR Code or a NFC Tag (Very Cheap, you can get 20 (NTAG213) for $20.00 on Amazon) You can download a Free NFC Tag Writer like NFC Tools (https://play.google.com/store/apps/details?id=com.wakdev.wdnfc) and write the text to the tag.  No expensive hardware or Internet based tracking software required.  You can't get any closer to an actual Punch Card than this.

As a Store Owner you would create a QR Code and Print it or program a Tag with your Store Name.  If you change the QR Code or the Tag, all users will need to reset the app to clear the currently paired QR/Tag.

Here is a quick video that demonstates how to Create a QR Code, They are showing how to create one with a URL, but doing Plain Text is the same concept.  https://www.youtube.com/watch?v=NtwCTo7T9zg FYI, this is not my video.

Here is a quick video that demonstates how to Write an NFC Tag, They are showing how to Write a URL to the tag, but doing Text is the same concept.  https://www.youtube.com/watch?v=DtzMie4U8RM FYI, this is not my video either.

As a User, you would download the App and scan the QR Code or Tap the Tag to register it with the app and get your first Credit.

Each Scan or Tap on the paired QR Code or NFC Tag earns 1 credit. Once the "FREE" item is redeemed, the card clears to start over.

Only 3 icons needed to customize for your store.  Not Punched, Punched and Punched Free.
You could use a Coffee cup, Sandwich, Ice Cream Cone, Car Washes, Oil Change, Muffins, Haircut, ...  You get the idea; the possibilities are endless.

Anyone want to make iOS version :-)


Store Owner - Create a QR Code and Print or Program an NFC tag with your Store Name, Example "Steve's BBQ" without the quotes - It would be best to write another TAG that has a link to the App on Google Play as well to make it easy for your customers.



<img src="http://www.soboapps.com/wp-content/uploads/2015/05/device-2016-04-16-120416.png">  <img src="http://www.soboapps.com/wp-content/uploads/2015/05/device-2016-04-16-120855.png">		

Customer would install the app and Tap the NFC tag.  The Store Name will automatically be displayed

<img src="http://www.soboapps.com/wp-content/uploads/2015/05/device-2016-04-16-121400.png">  <img src="http://www.soboapps.com/wp-content/uploads/2015/05/device-2016-04-09-113453.png">

<img src="http://www.soboapps.com/wp-content/uploads/2015/05/device-2016-04-16-121536.png">  <img src="http://www.soboapps.com/wp-content/uploads/2015/05/device-2016-04-09-114206.png">

<img src="http://www.soboapps.com/wp-content/uploads/2015/05/device-2016-04-09-113520.png">  <img src="http://www.soboapps.com/wp-content/uploads/2015/05/device-2016-04-09-113552.png">

Just a few examples of different Themes that could be used.

<img src="http://www.soboapps.com/wp-content/uploads/2015/05/device-2.png">  <img src="http://www.soboapps.com/wp-content/uploads/2015/05/device-3.png">

<img src="http://www.soboapps.com/wp-content/uploads/2015/05/device-4.png">  <img src="http://www.soboapps.com/wp-content/uploads/2015/05/device-5.png">


Todo list

* Change cards to Fragments. I think this is what is needed to have multiple accounts.
* Allow multiple card accounts
	Store each NFC Tag with a Company Name
		Currently the Card Name is pulled from the Text Field on th TAG and can be set manually, but this is only for 1 Tag.
